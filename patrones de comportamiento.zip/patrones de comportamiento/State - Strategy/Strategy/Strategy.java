package Patrones.Strategy;

public interface Strategy {
    // Interfaz Strategy que define el método común para todos los algoritmos
    int doOperation(int num1, int num2);
}
