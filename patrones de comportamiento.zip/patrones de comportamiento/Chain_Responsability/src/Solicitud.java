package Chain_Responsability.src;

public class Solicitud {

    private double monto;

    public Solicitud(double monto) {
        this.monto = monto;
    }

    public double getMonto() {
        return monto;
    }
}
