package Mediator;

public interface IUsuarioChat {
    public void recibe(String de, String mensaje);
    public void envia(String a, String mensaje);
}
