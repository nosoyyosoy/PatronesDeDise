public class Receiver {
    public void action() {
        System.out.println("Acción realizada");
    }
}
